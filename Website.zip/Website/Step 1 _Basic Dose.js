//How to Calculate your Personal Vitamin D Dosage
//Vitamin D Dosage needs to be tailored to each person. This is partly because the dose you need depends on the vitamin D level you are trying to achieve.

//This is what we mean by vitamin D levels

///25(OH)D Blood levels

//Vitamin D Status

//ng/ml	nmol/L
//Severely Deficient	0-10	0-25
//Deficient	11-20	26-50
//Insufficient	21-32	51-81
//Adequate	33-49	82-124
//Optimum	50-65	125-163
//High, but not toxic	66-100	164-250
//Toxicity possible	above 100	above 250
//The optimum range is where vitamin D most effectively promotes good health and fights disease.





//Step 1 – Basic Dose
//Use this simple rule to calculate your basic vitamin D dosage, based on your body mass. The answer will be in International Units of vitamin D, or IU.

//Basic daily vitamin D dosage = Body mass in pounds * 27 

//Examples
//Body Mass	Calculation	Daily Vitamin D (IU)
//200 pound adult	200 x 27	5400
//100 pound teenager	100 x 27	2700
//50 pound child	50 x 27	1350
//It works for any size of person, any age, male or female, pregnancy included.

//Why 27 IU per pound? Well, that’s the amount most people need to keep their 25(OH)D blood level near the optimum level of 50 ng/ml, without any help from sunlight.

//If you don’t ever allow direct sun on your skin, or don’t have access to strong sunshine, then you can skip step 2.


//Step 2 – Adjust for Sunlight
//Here is how you adjust for sunlight:

//Estimate how much of  your total skin area is exposed to strong, direct sunlight every day, on average. Would it be 5% or 10% or 20% or some other amount?
//Double that percentage
//Reduce your basic vitamin D dosage by that doubled percentage.
//That’s it, you’re done!



//Sunlight Adjustment Example
//Suppose your basic vitamin D daily dose (from Step 1) is 5400 IU, and you expose around 30% of your skin area to strong direct sun (wearing T-shirt and shorts) most days, in summer.

//You double that percentage which makes 60%, and calculate your sunlight adjustment as 60% of 5400 IU, which is 3240 IU.

//Now subtract the sunlight adjustment from your basic daily dose. Like this

//5400 – 3240 = 2160 IU.

//So your personal vitamin D dosage would be 2160 IU of vitamin D by mouth per day. Pretty simple, huh?

//What did you say? You can’t buy pills that size? Right! We’ll get to that problem a little later.

//First, let’s make sure we explained this sunlight adjustment properly.

//Calculate your Personal Vitamin D Dosage


//Vitamin D: The most commonly available vitamin D preparation is vitamin D3, or cholecalciferol.
//40 IU of vitamin D equals 1 µg, which can be converted to 0.001 mg.
//The RDA for an adult ranges from 600-800 IU.
//In micrograms, that would be 15 to 20 µg.
//Using milligrams changes the value range to 0.015-0.020 mg
// let ask = prompt("Estimate your skin exposure percentage (Look at skin% table)");
            
//         console.log("Your skin% of sun exposure is  " + ask );

let body = prompt("Enter your body mass in pound");
           body = parseFloat(body, 10);
           let secondNum = prompt("Please enter 27 IU");
            secondNum = parseFloat(secondNum, 10);
            function Multi (body,secondNum) {
                return body * secondNum;
            }

    console.log(Multi(body, secondNum));

let ask = prompt("Estimate your skin exposure percentage (Look at skin% table)");
ask = parseFloat(ask,10);
console.log("Your skin % of sun exposure is " + ask+ "%")

if (ask == "11%") {
            2 * ask;
            console.log(2 * ask);
        }else{
            if (ask == "18%"){
                2 * ask;
                console.log(2 * ask);
            }else{
                if (ask =="32%"){
                    2 * ask;
                    console.log(2 * ask);
                }else{
                    if (ask =="53%"){
                        2 * ask;
                        console.log(2 * ask);
                    }else{
                        if (ask =="73%"){
                            2 * ask;
                            console.log(2 * ask);
                        }else{
                            if (ask =="88%"){
                                2 * ask;
                                console.log(2 * ask);
                           
                            }
                        }
                
                    }
                }
            }
        }

let number = Multi(body, secondNum);
let percentage= 2 * ask;
let percentDecimal = percentage/100;
let calulation = percentDecimal * number
console.log("Your sunlight adjustment is"+ calulation);

let final = number - calulation;
console.log(final);

